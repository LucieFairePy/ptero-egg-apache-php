#!/bin/bash
php-fpm8.1
apache2ctl -D FOREGROUND