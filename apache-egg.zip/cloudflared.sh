#!/bin/bash
cloudflared service install ${CLOUDFLARED_TOKEN}